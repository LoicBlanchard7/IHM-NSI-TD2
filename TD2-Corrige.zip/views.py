from flask import *
import datetime

app = Flask(__name__)

@app.route('/')
def index():
    date = datetime.datetime.now()
    h = date.hour
    m = date.minute
    s = date.second
    return render_template("index.html", heure=h, minute=m, seconde=s)

@app.route('/explications')
def explications():
    return "<h1>Titre</h1><p>Voici notre page d'explications.</p>"

app.run(debug=True)

